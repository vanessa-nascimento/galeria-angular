const commentAPI = require('./comment')
    , photoAPI = require('./photo')
    , userAPI = require('./user');

module.exports = { commentAPI, photoAPI, userAPI };